# QuickCal
 chrome extension to easily add events to calendar app
