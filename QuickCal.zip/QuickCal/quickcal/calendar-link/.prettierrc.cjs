module.exports = require("@koj/config").prettier;
