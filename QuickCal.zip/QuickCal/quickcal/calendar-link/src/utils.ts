export const TimeFormats = {
  dateTimeLocal: "YYYY-MM-DD[T]HH:mm:ss",
  dateTimeUTC: "YYYYMMDD[T]HHmmss[Z]",
  allDay: "YYYYMMDD",
};
