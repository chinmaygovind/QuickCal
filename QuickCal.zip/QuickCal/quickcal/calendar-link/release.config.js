module.exports = require("@koj/config").releaseMaster;
